make sure to install vine w/ pip install vine
	if missing modules likely part of vine, make sure its all in the right place/installed

easiest to install pycharm, then put myshop folder in the PyCharmProjects directory
	to install python packages to pycharm you have to put the package folder installed with pip/downloaded into this directory
		..\.virtualenvs\project-izGewC6x\Lib\site-packages
	or something similar. The .virtualenvs folder should be in the same place as PyCharmProjects, for me in my user folder




to make edits, first run "python manage.py runserver". either use the command prompt, or in PyCharm click on the Tools dropdown menu, then "run manage.py task", then "runserver"
once runserver is going, go to http://127.0.0.1:8000/admin in your browser
click on products, then each product will have an "add image button"

to check your changes, go to http://127.0.0.1:8000 and it should display the product page along with the images you applied.