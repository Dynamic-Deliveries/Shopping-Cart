make sure to install vine w/ pip install vine
	if missing modules likely part of vine, make sure its all in the right place/installed
install rabbitmq + erlang as well so website can communicate across multiple platforms at the same time


shop and cart pages not linked properly, but not sure why

otherwise fully functioning basic shopping cart